import {Hero} from './hero';
export const HEROES:Hero[]=[
    {"id":11 , "name":'Shivanshu'},
    {"id":12, "name" :'Anshu'},
    {"id":13, "name":'Shivu'},
    {"id":14, "name":'Shivi'},
    {"id":15, "name":'Anshi'},
    {"id":16, "name":'Vah'},
]