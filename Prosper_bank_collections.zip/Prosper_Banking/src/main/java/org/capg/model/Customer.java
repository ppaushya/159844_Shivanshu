package org.capg.model;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

public class Customer {
private int customerId;
private String firstName;
private String lastName;
private LocalDate dateOfBirth;
private String mobile;
private String email;
private Address address;
private Set<Account> account=new HashSet<>();
public Customer() {
	
}
public Customer(int customerId, String firstName, String lastName, LocalDate dateOfBirth, String mobile,
		String email, Address address, Set<Account> account) {
	super();
	this.customerId = customerId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.dateOfBirth = dateOfBirth;
	this.mobile = mobile;
	this.email = email;
	this.address = address;
	this.account = account;
}
public Customer(Set<Account> account) {
	super();
	this.account = account;
}
public Customer(int customerId, String firstName, String lastName, LocalDate dateOfBirth, String mobile,
		String email, Address address) {
	super();
	this.customerId = customerId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.dateOfBirth = dateOfBirth;
	this.mobile = mobile;
	this.email = email;
	this.address = address;
	
}

@Override
public String toString() {
	return "Customer [customerId=" + customerId + ", firstName=" + firstName + ", lastName=" + lastName
			+ ", dateOfBirth=" + dateOfBirth + ", mobile=" + mobile + ", email=" + email + ", address="
			+ address + ", account=" + account + "]";
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public LocalDate getDateOfBirth() {
	return dateOfBirth;
}
public void setDateOfBirth(LocalDate dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}
public String getMobile() {
	return mobile;
}
public void setMobileNo(String mobile) {
	this.mobile = mobile;
}
public String getEmail() {
	return email;
}
public void setEmailId(String email) {
	this.email = email;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}
public Set<Account> getAccount() {
	return account;
}
public void setAccount(Set<Account> account) {
	this.account = account;
}
}
