package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Main
 */
public class Main extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Main() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter writer=response.getWriter();
		String out="<html>\r\n" + 
				"<head>\r\n" + 
				"<title>\r\n" + 
				"Services\r\n" + 
				"</title>\r\n" + 
				"</head>\r\n" + 
				"\r\n" + 
				"<body>\r\n" + 
				"<div>\r\n" + 
				"<ul>\r\n" + 
				"<li><a href=\"view/createAccount.html\">Create account</a></li>\r\n" + 
				"<li><a href=\"view/createAccount.html\">Create account</a></li>\r\n" + 
				"<li><a href=\"Logout\">Logout</a></li>\r\n" + 
				"\r\n" + 
				"<iframe name=\"frame1\" width=\"500px\" height=\"300px\" src=\"view/frame.html\"></iframe>\r\n" + 
				"</ul>\r\n" + 
				"</div>\r\n" + 
				"</body>\r\n" + 
				"</html>";
		
		writer.println(out);
		
	}

}
