package org.cap.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.Bean.Customer;
import org.cap.service.ILoginService;
import org.cap.service.LoginServiceImpl;


/**
 * Servlet implementation class Login
 */
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ILoginService loginService=new LoginServiceImpl();
		
		String userName=request.getParameter("userName");
		String password=request.getParameter("passWord");
		
		org.cap.Bean.Login login=new org.cap.Bean.Login();
		login.setUserName(userName);
		login.setPassWord(password);
		
		Customer customer=loginService.isValidLogin(login);
		if(customer!=null) {
			HttpSession session=request.getSession();
			session.setAttribute("name", customer.getName());
			
			request.getRequestDispatcher("Main").forward(request, response);
			
		}
		
		else response.sendRedirect("index.html");
		
		
		
	}

}
