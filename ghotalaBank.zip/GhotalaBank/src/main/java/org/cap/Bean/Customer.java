package org.cap.Bean;

import java.time.LocalDate;

public class Customer {
	
	private int custId;
	private String name;
	private LocalDate dob;
	private String email;
	private String password;
	private Address address;
	
	
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", name=" + name + ", dob=" + dob + ", email=" + email + ", password="
				+ password + ", address=" + address + "]";
	}
	public Customer(int custId, String name, LocalDate dob, String email, String password, Address address) {
		super();
		this.custId = custId;
		this.name = name;
		this.dob = dob;
		this.email = email;
		this.password = password;
		this.address = address;
	}
	
	
	public Customer() {
		
	}
	
	
	

}
