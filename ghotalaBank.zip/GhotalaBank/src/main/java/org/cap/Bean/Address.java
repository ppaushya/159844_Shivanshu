package org.cap.Bean;

public class Address {

	private int addressId;
	private int custId;
	private String addressLine1;
	private String city;
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", custId=" + custId + ", addressLine1=" + addressLine1 + ", city="
				+ city + "]";
	}
	public Address(int addressId, int custId, String addressLine1, String city) {
		super();
		this.addressId = addressId;
		this.custId = custId;
		this.addressLine1 = addressLine1;
		this.city = city;
	}
	public Address() {
		
	}
	
	
}
