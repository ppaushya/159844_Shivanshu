package org.cap.service;

import org.cap.Bean.Customer;
import org.cap.Bean.Login;
import org.cap.dao.ILoginDao;
import org.cap.dao.LoginDaoImpl;

public class LoginServiceImpl implements ILoginService {

	ILoginDao loginDao=new LoginDaoImpl();
	
	@Override
	public Customer isValidLogin(Login login) {
		
		return loginDao.isValidLogin(login);
	}

}
