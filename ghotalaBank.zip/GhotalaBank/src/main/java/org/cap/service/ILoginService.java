package org.cap.service;
import org.cap.Bean.Customer;
import org.cap.Bean.Login;

public interface ILoginService {
	
	public Customer isValidLogin(Login login);

}
