package org.cap.dao;

import org.cap.Bean.Customer;
import org.cap.Bean.Login;

public interface ILoginDao {

	public Customer isValidLogin(Login login);
}
