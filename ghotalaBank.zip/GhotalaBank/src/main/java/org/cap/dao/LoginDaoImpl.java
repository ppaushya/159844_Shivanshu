package org.cap.dao;




import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.cap.Bean.Customer;
import org.cap.Bean.Login;



public class LoginDaoImpl implements ILoginDao {

	
	public Connection getConnection() {
		
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");

		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return conn;
		
	}
	
	
	@Override
	public Customer isValidLogin(Login login) {
		
		String sql="Select * from customer where email=? and password=?";
		try {
			PreparedStatement pst=getConnection().prepareStatement(sql);
			pst.setString(1, login.getUserName());
			pst.setString(2, login.getPassWord());
			
			ResultSet rs=pst.executeQuery();
			
			if(rs.next()) {
				Customer customer=new Customer();
				customer.setName(rs.getString("firstName"));
				customer.setDob(rs.getDate("dateOfBirth").toLocalDate());
				customer.setEmail(rs.getString("email"));
				customer.setCustId(Integer.parseInt(rs.getString("customerId")));
				return customer;
				
				
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
				
		return null;
	}

}
