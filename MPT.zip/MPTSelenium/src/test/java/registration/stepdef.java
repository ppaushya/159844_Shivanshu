package registration;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {
	
	private WebDriver webdriver;
	private WebElement element;
	private Alert alertboxtry;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\shivans\\Desktop\\selenium\\chromedriver.exe");
		webdriver=new ChromeDriver();
	
	}
	
	@Given("^Open conference registration page$")
	public void open_conference_registration_page() throws Throwable {
		webdriver.get("file:///C:/Users/shivans/Desktop/selenium/Conferencebooking/ConferenceRegistartion.html#");
		String title=webdriver.getTitle();
		assertEquals( "Conference Registartion", title);
	}

	@Given("^provide registration details$")
	public void provide_registration_details() throws Throwable {
	   //first name alerts
		element=webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
		element.click();
		String msg=webdriver.switchTo().alert().getText();
		
		Thread.sleep(1000);
		webdriver.switchTo().alert().accept();
		webdriver.findElement(By.name("txtFN")).sendKeys("Ramlal");
		
		//last name alerts
				element=webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
				element.click();
				Thread.sleep(1000);
				webdriver.switchTo().alert().accept();
		
		webdriver.findElement(By.name("txtLN")).sendKeys("Daroga");
		
		//email alerts
				element=webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
				element.click();
				Thread.sleep(1000);
				webdriver.switchTo().alert().accept();
		webdriver.findElement(By.name("Email")).sendKeys("lal@gmail.com");
		
		//phone alerts
				element=webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
				element.click();
				Thread.sleep(1000);
				webdriver.switchTo().alert().accept();
		webdriver.findElement(By.name("Phone")).sendKeys("9877076360");
		
		//no of people alerts
		element=webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
		element.click();
		Thread.sleep(1000);
		webdriver.switchTo().alert().accept();
		Select select=new Select(webdriver.findElement(By.name("size")));
		select.selectByIndex(2);
		Thread.sleep(1000);
		webdriver.findElement(By.name("Address")).sendKeys("Mohalla thakur ka");
		Thread.sleep(1000);
		webdriver.findElement(By.name("Address2")).sendKeys("Ramgarh");
		Thread.sleep(1000);
		Select city=new Select(webdriver.findElement(By.name("city")));
		city.selectByIndex(1);
		Thread.sleep(1000);
		Select state=new Select(webdriver.findElement(By.name("state")));
		state.selectByIndex(1);
		Thread.sleep(1000);
		webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input")).click();
		Thread.sleep(1000);
		
		
	}

	@When("^Submit validate login details and click next$")
	public void submit_validate_login_details_and_click_next() throws Throwable {
	   element=webdriver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
	   element.click();
	}

	@Then("^navigate to payment page$")
	public void navigate_to_payment_page() throws Throwable {
	   
		Alert alertbox=webdriver.switchTo().alert();
		alertbox.accept();
		webdriver.close();
		
	}

	@Given("^payment page$")
	public void payment_page() throws Throwable {
		//webdriver.get("file:///C:/Users/shivans/Desktop/selenium/Conferencebooking/PaymentDetails.html");
		
		webdriver.get("file:///C:/Users/shivans/Desktop/selenium/Conferencebooking/PaymentDetails.html");
		String title=webdriver.getTitle();
		assertEquals("Payment Details", title);
	   
	}

	@Given("^payment details$")
	public void payment_details() throws Throwable {
	   webdriver.findElement(By.name("txtFN")).sendKeys("Shivanshu Vah");
	   webdriver.findElement(By.name("debit")).sendKeys("123456789");
	   webdriver.findElement(By.name("cvv")).sendKeys("032");
	   webdriver.findElement(By.name("month")).sendKeys("04");
	   webdriver.findElement(By.name("year")).sendKeys("1996");
	   
	   
		
	}

	@When("^Submit validate payment details and click make payment$")
	public void submit_validate_payment_details_and_click_make_payment() throws Throwable {
		webdriver.findElement(By.id("btnPayment")).click();
	}

	@Then("^display confirmation message$")
	public void display_confirmation_message() throws Throwable {
		Alert alertboxcnf=webdriver.switchTo().alert();
		alertboxcnf.accept();
	}


}
