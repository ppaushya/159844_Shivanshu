package org.capg;

public class Sender<T> {
private T message;
//R medium;

public T getMessage() {
	return message;
}

public void setMessage(T message) {
	this.message = message;
}
	
	
}
