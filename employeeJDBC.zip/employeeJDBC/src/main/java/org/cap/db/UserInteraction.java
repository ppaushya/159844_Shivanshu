package org.cap.db;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class UserInteraction {
Scanner scan=new Scanner(System.in);

public Employee promptEmployee() {
	Employee employee =new Employee();
	System.out.println("Enter Employee Id:");
	employee.setEmpId(scan.nextInt());
	System.out.println("Enter Employee FirstName: ");
	employee.setFirstName(scan.next());
	System.out.println("Enter Employee LastName");
	employee.setLastName(scan.next());
	System.out.println("Enter Employee Salary");
	employee.setSalary(scan.nextDouble());
	System.out.println("Enter Employee Date Of Joining [yyyy-mm-dd]");
	String[] date=scan.next().split("-");
	employee.setEmpdoj(LocalDate.of(
			Integer.parseInt(date[0]), 
			Integer.parseInt(date[1]), 
			Integer.parseInt((date[2]))));
	
	return employee;
}
public int promptEmployeeId() {
	System.out.println("Enter EmployeeId:");
	return scan.nextInt();
}
public void printAllEmployees(List<Employee> employee)
{
	
	System.out.println("EmployeeId\tFirstName\tLastName\tSalary\tDate of Joining");
	for(Employee emp:employee)
	{
		System.out.println(emp.getEmpId()+"\t\t"+emp.getFirstName()+"\t\t"+emp.getLastName()+"\t\t"+emp.getSalary()+"\t\t"+emp.getEmpdoj());
	}
}
public void findEmployee(Employee emp) {
	// TODO Auto-generated method stub
	System.out.println("EmployeeId\tFirstName\tLastName\tSalary\tDate of Joining");
	System.out.println(emp.getEmpId()+"\t\t"+emp.getFirstName()+"\t\t"+emp.getLastName()+"\t\t"+emp.getSalary()+"\t\t"+emp.getEmpdoj());
}
public String promptFirstName() {
	
	System.out.println("Enter Employee FirstName:");
	return scan.next();
}
public String promptLastName() {
	
	System.out.println("Enter Employee LastName:");
	return scan.next();
}
public double promptSalary()
{
	System.out.println("Enter Employee Salary:");
	return scan.nextDouble();
	
}
public LocalDate promptDate() {
System.out.println("Enter Employee Date Of Joining:");
String[] date=scan.next().split("-");
return LocalDate.of(Integer.parseInt(date[0]), Integer.parseInt(date[1]), Integer.parseInt(date[2]));
 
}

}
