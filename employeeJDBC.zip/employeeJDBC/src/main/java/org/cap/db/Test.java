package org.cap.db;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;


public class Test {
	public static void main(String[] args)
	{
		  //Connection connection=null;
		//1.Load Driver Class
		try(Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123")) {
			Class.forName("com.mysql.jdbc.Driver");
			//2.Connection establishment
			//gives sqlException
			//String sql="create table employee1(empid int primary key,firstName varchar(25) not null,"
			//		+"lastName varchar(25),salary numeric(8,2),empdoj date)";
			String sql="insert into employee values(1,'tom)";
			//3.statement
			Statement statement =connection.createStatement();
			boolean flag=statement.execute(sql);
			//if flag is false creation success
			if(!flag)
			{
				System.out.println("Table created successfully!");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}*/
	}

}
