package org.capg.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.AccountServiceImpl;
import org.capg.service.IAccountService;
import org.capg.service.ITransactionService;
import org.capg.service.TransactionServiceImpl;

/**
 * Servlet implementation class FundTransfer
 */
@WebServlet("/FundTransfer")
public class FundTransfer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ITransactionService transervice=new TransactionServiceImpl();
		Transaction transaction=new Transaction();
		Transaction transaction1=new Transaction();
		IAccountService accservice=new AccountServiceImpl();
		
		transaction.setTransactionDate(LocalDate.now());
		transaction.setAmount(Double.parseDouble(request.getParameter("amount")));
		
		int fromaccountNo=Integer.parseInt(request.getParameter("fromaccountNo"));
				transaction.setFromAccount(fromaccountNo);
				int toaccountNo=Integer.parseInt(request.getParameter("toaccountNo"));
				transaction.setToAccount(toaccountNo);
		transaction.setDescription(request.getParameter("desc"));
		transaction.setTransactionType("Debit");
		HttpSession session=request.getSession();
		int custId=Integer.parseInt(session.getAttribute("custId").toString());
		Customer customer=new Customer();
		customer.setCustomerId(custId);
		transaction.setCustomerId(custId);
		transervice.createTransaction(transaction);
		
		transaction1.setTransactionDate(LocalDate.now());
		transaction1.setAmount(Double.parseDouble(request.getParameter("amount")));
		
		int accountNo=Integer.parseInt(request.getParameter("toaccountNo"));
				transaction1.setFromAccount(accountNo);
				int toaccountNo1=Integer.parseInt(request.getParameter("fromaccountNo"));
				transaction1.setToAccount(toaccountNo1);
				transaction1.setTransactionType("Credit");
		transaction1.setDescription(request.getParameter("desc"));
		Set<Account> accounts=accservice.getAccounts(customer);
		int custId1=0;
		System.out.println(accounts);
		for(Account account:accounts) {
			
	        if(account.getAccountNo()==toaccountNo)
	        	{ 
	        	  
		          custId1=account.getCustomer().getCustomerId();
	            System.out.println(custId1);
	        	}
		}
		transaction1.setCustomerId(custId1);
		transervice.createTransaction(transaction1);
		 response.sendRedirect("FundTransferServlet");
	}

}
