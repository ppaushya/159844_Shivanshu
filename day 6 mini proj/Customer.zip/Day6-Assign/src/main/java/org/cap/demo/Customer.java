package org.cap.demo;

public class Customer {

	private int custId;
	private String custName;
	private Address address;
	private Account account[];
	private String emailId;
	private long mobileNo;
	
	
	public Customer() {
		//default constructor
	}
	
	public int getCustId() {
		return this.custId;
	}
	
	public void setCustId(int custId) {
		this.custId=custId;
	}
	
	public String getCustName() {
		return this.custName;
	}
	
	public void setCustName(String custName) {
		this.custName=custName;
		
	}
	
	
}
