package org.cap.demo;

public class Address {
	
	private int houseNo;
	private String streetName;
	private String area;
	private String city;
	private String state;
	private int pinCode;
}
