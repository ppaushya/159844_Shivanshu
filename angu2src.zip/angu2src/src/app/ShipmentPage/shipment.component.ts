import { Component } from "@angular/core";

@Component({

    selector:'ship-root',
    templateUrl:'./shipment.component.html',
    styleUrls:['./shipment.component.css']

})
  export class ShipmentComponent{

  }  