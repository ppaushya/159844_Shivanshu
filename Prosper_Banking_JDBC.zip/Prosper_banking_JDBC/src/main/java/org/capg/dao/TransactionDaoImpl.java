package org.capg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Transaction;

public class TransactionDaoImpl implements ITransactionDao {

		Map<Account, List<Transaction>> transactions=new HashMap<Account, List<Transaction>>();
		
	@Override
	public List<Transaction> getAllTransactions(Account account) {
		// TODO Auto-generated method stub
		List<Transaction> transactions=new ArrayList<>();
		String str="select * from acc_transaction where fromAccount="+account.getAccountNo()+" or toAccount="+account.getAccountNo()+";";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);
			ResultSet resultSet= statement.executeQuery();
			
			
			while(resultSet.next())
			{
				Transaction transaction=new Transaction();
				
					transaction.setTransactionId(resultSet.getInt(1));
					transaction.setTransactionDate(resultSet.getDate(2).toLocalDate());
					transaction.setTransactionType(resultSet.getString(3));
					transaction.setAmount(resultSet.getDouble(4));
					if(resultSet.getLong(5)!=0)
						transaction.setFromAccount(account);
					else
						transaction.setFromAccount(null);
					if(resultSet.getLong(6)!=0)
						transaction.setToAccount(account);
					else
						transaction.setToAccount(null);
					transaction.setDescription(resultSet.getString(7));
		
					transactions.add(transaction);
			
				
			}
		}	catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return transactions;
	}
	
	
	@Override
	public void createTransaction(Account account, Transaction transaction) {
		// TODO Auto-generated method stub
		String sql="insert into acc_transaction values(?,?,?,?,?,?,?);";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setLong(1, transaction.getTransactionId());
			statement.setDouble(4, transaction.getAmount());
			statement.setString(3, transaction.getTransactionType());
			statement.setDate(2, java.sql.Date.valueOf(transaction.getTransactionDate()));
			if(transaction.getFromAccount()!=null)
				statement.setLong(5, transaction.getFromAccount().getAccountNo());
			else
				statement.setLong(5, 0);
			if(transaction.getToAccount()!=null)
				statement.setLong(6, transaction.getToAccount().getAccountNo());
			else
				statement.setLong(6, 0);
			statement.setString(7, transaction.getDescription());
			
		
			int row=statement.executeUpdate();
			
			if(row>0)
				System.out.println(row+" row inserted successfully in Transactions table!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}

	

}
