package org.capg.boot;

public class TestClass {

	public static void main(String[] args) {
		
	}

}
