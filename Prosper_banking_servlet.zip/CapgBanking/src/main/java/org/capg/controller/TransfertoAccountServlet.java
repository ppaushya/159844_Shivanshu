package org.capg.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.AccountServiceImpl;
import org.capg.service.IAccountService;
import org.capg.service.ITransactionService;
import org.capg.service.TransactionServiceImpl;


@WebServlet("/TransfertoAccountServlet")
public class TransfertoAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 IAccountService accountservice=new AccountServiceImpl();

		String accountNumber=request.getParameter("fromAccount");
		String accountNumber1=request.getParameter("toAccount");
		String transactionType="FundsTransfer";
		String amount=request.getParameter("amount");
		String description=request.getParameter("description");
		 
		Account account=new Account();
		 Transaction transaction=new Transaction();
		 transaction.setTransactionDate(LocalDate.now());
		 transaction.setAmount(Double.parseDouble(amount));
		 transaction.setTransactionType(transactionType);
		 transaction.setDescription(description);
		// account.setAccountNumber(Integer.parseInt(accountNumber1));
		 transaction.setToAccount(Integer.parseInt(accountNumber1));
		 transaction.setFromAccount(Integer.parseInt(accountNumber));
		 
		 HttpSession session=request.getSession();
		   int custId=Integer.parseInt(session.getAttribute("CustId").toString());
		   Customer customer=new Customer();
		   customer.setCustomerId(custId);
		   transaction.setCustomerId(custId);
		   
		   ITransactionService transactionservice=new TransactionServiceImpl();
		   
			 Account acc=accountservice.getAccount(Integer.parseInt(accountNumber));
			
			 if(transaction.getAmount()<=acc.getOpeningBalance())
			      {
				  
				  if(transactionservice.createFundsTransaction(transaction))
				  {
				   response.sendRedirect("FundsTransfer");
				   System.out.println("Transaction Done!");
			      }
				  else
				  {
					  System.out.println("Transaction failed!");
				  }
			    }
			 else
			 System.out.println("Transaction Failed!");
		 
		
	}

}
