package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.ITransactionService;
import org.capg.service.TransactionServiceImpl;


@WebServlet("/TransactionSummaryPost")
public class TransactionSummaryPost extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ITransactionService transactionService=new TransactionServiceImpl();
		List<Transaction> transactions=new ArrayList<Transaction>();
		Map<Account, Double> currentBalDetails=new HashMap<>();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	
		HttpSession session=request.getSession();
		int custId=Integer.parseInt(session.getAttribute("CustId").toString());
		 Customer customer=new Customer();
		 customer.setCustomerId(custId);
         //account.setCustomer(customer);
		
		String fromDateString=request.getParameter("fromDate");
		LocalDate fromDate=LocalDate.parse(fromDateString, formatter);
		
		String toDateString=request.getParameter("toDate");
		LocalDate toDate=LocalDate.parse(toDateString, formatter);
		
		
	   transactions=transactionService.getTransactionsForCustomer(custId, fromDate, toDate);
		currentBalDetails=transactionService.getCurrentBalance(custId);
		
		PrintWriter out=response.getWriter();
		
		out.println("<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<head>\r\n" + 
				"<meta charset=\"ISO-8859-1\">\r\n" + 
				"<title>CapgBanking</title>\r\n" + 
				"<link type=\"text/css\" rel=\"stylesheet\" href=\" styles/summaryPost.css\">\r\n" +
				"</head>\r\n" + 
				"<body>" + 
				"	<div class=\"centercnt\">\r\n" +
				"	<h3 align=\"center\">Transaction Summary:</h3>" +
				"	<table align=\"center\" border=1>" + 
				"			<tr>" + 
				"				<th>Date</th>" + 
				"				<th>From Account</th>" + 
				"				<th>To Account</th>" + 
				"				<th>Transaction Type</th>" + 
				"				<th>Amount</th>" + 
				"			</tr>");
		
		for(Transaction transaction:transactions) {
			
			out.println("<tr>" + 
					"				<td>"+transaction.getTransactionDate().toString()+"</td>\r\n" + 
					"				<td>"+transaction.getFromAccount()+"</td>\r\n" + 
					"				<td>"+transaction.getToAccount()+"</td>\r\n" + 
					"				<td>"+transaction.getTransactionType()+"</td>\r\n" + 
					"				<td>"+transaction.getAmount()+"</td>\r\n" + 
					"			</tr>");
			
		}
		
		out.println("</table>\r\n"
				+ "<br><h3 align=\"center\">Current Balance Of Accounts:</h3>"+
				"	<table align=\"center\" border=1>\r\n" + 
				"			<tr>\r\n" + 
				"				<th>Account Number</th>\r\n" + 
				"				<th>Account Type</th>\r\n" + 
				"				<th>Current Balance</th>\r\n" + 
				"			</tr>\r\n");
		
		for(Account account:currentBalDetails.keySet())	{
			
			out.println("<tr>\r\n" + 
					"				<td>"+account.getAccountNumber()+"</td>\r\n" + 
					"				<td>"+account.getAccountType()+"</td>\r\n" + 
					"				<td>"+currentBalDetails.get(account)+"</td>\r\n" + 
					"			</tr>\r\n");
		}
		
	}
	}


