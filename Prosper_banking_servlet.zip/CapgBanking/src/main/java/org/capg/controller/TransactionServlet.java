package org.capg.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.AccountServiceImpl;
import org.capg.service.IAccountService;
import org.capg.service.ILoginService;
import org.capg.service.ITransactionService;
import org.capg.service.LoginServiceImpl;
import org.capg.service.TransactionServiceImpl;


@WebServlet("/TransactionServlet")
public class TransactionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ITransactionService transactionservice=new TransactionServiceImpl();
		 IAccountService accountservice=new AccountServiceImpl();
		Account account=new Account();
		 String accountNo=request.getParameter("accountNo");
		 String description=request.getParameter("description");
		 String amount=request.getParameter("amount");
		 String transactionType=request.getParameter("DepWith");
		 
		 Transaction transaction=new Transaction();
		 transaction.setTransactionDate(LocalDate.now());
		 transaction.setAmount(Double.parseDouble(amount));
		 transaction.setTransactionType(transactionType);
		 transaction.setDescription(description);
		 account.setAccountNumber(Integer.parseInt(accountNo));
		// transaction.setToAccount(0);
		// transaction.setFromAccount(Integer.parseInt(accountNo));
		 
		 HttpSession session=request.getSession();
		   int custId=Integer.parseInt(session.getAttribute("CustId").toString());
		   Customer customer=new Customer();
		   customer.setCustomerId(custId);
		   transaction.setCustomerId(custId);
		 
		 Account acc=accountservice.getAccount(Integer.parseInt(accountNo));
		
		 if(transaction.getTransactionType().equals("Debit")) { 
			 transaction.setToAccount(0);
			transaction.setFromAccount(Integer.parseInt(accountNo));
			 
		   if(transaction.getAmount()<=acc.getOpeningBalance())
		      {
			  
			  if(transactionservice.createTransaction(transaction))
			  {
			   response.sendRedirect("DepositWithdrawServlet");
			   System.out.println("Transaction Done!");
		      }
		      }
		   /* else {
			   response.sendRedirect("");   
		         }*/
		}
		  else  if(transaction.getTransactionType().equals("Credit")) {
			  
			  transaction.setToAccount(Integer.parseInt(accountNo));
			  transaction.setFromAccount(0);
			  
			  if(transactionservice.createTransaction(transaction))
			  {
			   response.sendRedirect("DepositWithdrawServlet");
			   System.out.println("Transaction Done!");
		      }
		  }   
		  else
			  System.out.println("failed!");
		
		   }
		 
		
		 
	}

