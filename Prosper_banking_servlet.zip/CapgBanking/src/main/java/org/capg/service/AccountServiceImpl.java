package org.capg.service;

import java.util.List;

import org.capg.dao.AccountDaoImpl;
import org.capg.dao.IAccountDao;
import org.capg.model.Account;
import org.capg.model.Customer;

public class AccountServiceImpl implements IAccountService{
	
	IAccountDao accountDao=new AccountDaoImpl();
	
	@Override
	public Account getAccount(int accountNo) {
		return accountDao.getAccount(accountNo);
	}

	@Override
	public List<Account> getAllAccounts(Customer customer) {
		return accountDao.getAllAccounts(customer);
	}
	

	@Override
	public Account createAccount(Account account) {
		
		return accountDao.createAccount(account);
	}

	@Override
	public List<Account> getAlltoAccounts(Customer customer) {
		// TODO Auto-generated method stub
		return accountDao.getAlltoAccounts(customer);
	}

}
